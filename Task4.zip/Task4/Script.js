let scores = [45, 82, 91, 60, 77, 33];

function displayScores() {

    const scoresContainer = document.getElementById("scores");

    scoresContainer.innerHTML = "";

    scores.forEach(function(score) {

        const scoreElement = document.createElement("div");

        scoreElement.textContent = score;

        scoreElement.classList.add("score");

        // Change color according to score
        if (score >= 90) {
            scoreElement.classList.add("high");
        }
        else if (score >= 60) {
            scoreElement.classList.add("medium");
        }
        else {
            scoreElement.classList.add("low");
        }

        scoresContainer.appendChild(scoreElement);
    });

    calculateStatistics();
}


function calculateStatistics() {

    const highest = Math.max(...scores);

    const lowest = Math.min(...scores);

    const total = scores.reduce(function(sum, score) {
        return sum + score;
    }, 0);

    const average = total / scores.length;

    document.getElementById("statistics").textContent =
        `Highest: ${highest} | Lowest: ${lowest} | Average: ${average.toFixed(1)}`;
}


function addScore() {

    const input = document.getElementById("newScore");

    const score = Number(input.value);

    // Check score
    if (input.value === "") {
        alert("Please enter a score.");
        return;
    }

    if (score < 0 || score > 100) {
        alert("Score must be between 0 and 100.");
        return;
    }

    // Add score
    scores.push(score);

    // Clear input
    input.value = "";

    // Display again
    displayScores();
}


// Display scores when page loads
displayScores();