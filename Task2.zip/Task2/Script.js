function checkGrade() {

    let score = Number(document.getElementById("score").value);
    let result = document.getElementById("result");

    if (score === "" || isNaN(score)) {
        result.textContent = "Please enter a score.";
        result.style.color = "red";
        return;
    }

    if (score < 0 || score > 100) {
        result.textContent = "Score must be between 0 and 100.";
        result.style.color = "red";
        return;
    }

    let grade;

    if (score >= 90) {
        grade = "A";
        result.style.color = "green";
    }
    else if (score >= 80) {
        grade = "B";
        result.style.color = "green";
    }
    else if (score >= 70) {
        grade = "C";
        result.style.color = "orange";
    }
    else if (score >= 60) {
        grade = "D";
        result.style.color = "orange";
    }
    else {
        grade = "F";
        result.style.color = "red";
    }

    result.textContent = `Score: ${score} - Grade ${grade}`;
}