function generateTable() {

    let number = document.getElementById("number").value;
    let table = document.getElementById("table");
    let tableBody = document.getElementById("tableBody");

    // Clear old table
    tableBody.innerHTML = "";

    // Check input
    if (number === "") {
        alert("Please enter a number.");
        return;
    }

    // Generate 1 to 9
    for (let i = 1; i <= 9; i++) {

        let result = number * i;

        let row = document.createElement("tr");

        let expression = document.createElement("td");
        expression.textContent = `${number} × ${i}`;

        let resultCell = document.createElement("td");
        resultCell.textContent = result;

        row.appendChild(expression);
        row.appendChild(resultCell);

        tableBody.appendChild(row);
    }

    // Show table
    table.style.display = "table";
}