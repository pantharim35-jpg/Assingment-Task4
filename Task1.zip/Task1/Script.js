const btn = document.getElementById("btn");
const more = document.getElementById("more");

btn.addEventListener("click", function () {

    if (more.style.display === "block") {
        more.style.display = "none";
        btn.innerHTML = "Show more";
    } else {
        more.style.display = "block";
        btn.innerHTML = "Show less";
    }

});