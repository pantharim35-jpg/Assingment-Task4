let tasks = [];


function addTask() {

    const input = document.getElementById("taskInput");

    const text = input.value.trim();

    // Check empty task
    if (text === "") {
        return;
    }

    // Create task object
    const task = {
        id: Date.now(),
        text: text,
        completed: false
    };

    tasks.push(task);

    input.value = "";

    displayTasks();
}


function displayTasks() {

    const taskList = document.getElementById("taskList");

    taskList.innerHTML = "";

    tasks.forEach(function(task) {

        const taskElement = document.createElement("div");

        taskElement.classList.add("task");

        if (task.completed) {
            taskElement.classList.add("completed");
        }

        // Click task = complete / uncomplete
        taskElement.onclick = function() {
            toggleTask(task.id);
        };


        // Task name
        const taskName = document.createElement("span");

        taskName.classList.add("task-name");

        taskName.textContent = task.text;


        // Delete button
        const deleteButton = document.createElement("span");

        deleteButton.classList.add("delete");

        deleteButton.textContent = "x";


        deleteButton.onclick = function(event) {

            event.stopPropagation();

            deleteTask(task.id);
        };


        taskElement.appendChild(taskName);

        taskElement.appendChild(deleteButton);

        taskList.appendChild(taskElement);
    });

    updateCounter();
}


function toggleTask(id) {

    tasks = tasks.map(function(task) {

        if (task.id === id) {
            task.completed = !task.completed;
        }

        return task;
    });

    displayTasks();
}


function deleteTask(id) {

    tasks = tasks.filter(function(task) {
        return task.id !== id;
    });

    displayTasks();
}


function updateCounter() {

    const total = tasks.length;

    const completed = tasks.filter(function(task) {
        return task.completed;
    }).length;

    document.getElementById("counter").textContent =
        `${completed} of ${total} tasks done`;
}


// Press Enter to add task
document.getElementById("taskInput").addEventListener(
    "keydown",
    function(event) {

        if (event.key === "Enter") {
            addTask();
        }
    }
);